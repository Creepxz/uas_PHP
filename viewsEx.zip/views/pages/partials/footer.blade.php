


<!-- Footer -->
<footer class="page-footer elegant-color" if="footer" id="contact">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <p class="white-text text-center"><a href="{{ url('admin/dashboard') }}">ADMIN</a></p>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            <div class="col-md-10 col-md-offset-1 text-center"><a href="http://davidtrushkov.com/" target="_blank">© 2016 Copyright David Trushkov</a></div>
        </div>
    </div>
</footer>