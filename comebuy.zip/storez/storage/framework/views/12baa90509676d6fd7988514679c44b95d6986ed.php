<?php $__env->startSection('pages'); ?>
<style>
    html, body {font-family: 'Lato'; }
    .fa-btn { margin-right: 6px;}
    .col-lg-2{ background-color: #fff;}
    .navbar { background-color: #24F5B5  
</style>
<div class="row">
    <div class="col-lg-2">
        <div class="container">
            <?php echo $__env->make('signin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
        </div>
    <div class="col-lg-10"> 
        <div class="container">
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>