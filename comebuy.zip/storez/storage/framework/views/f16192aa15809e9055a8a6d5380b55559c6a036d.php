<?php if(count($errors)>0): ?>
<div class="alert alert-danger">
    <!--ul untuk membuat bullet,ol untuk membuat numbering -->
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php if(session()->has('members')): ?>
    <h4>Welcome, <?php echo e(session('members')); ?></h4>
    <a href="<?php echo e(url('logout')); ?>">Log Out</a>
<?php else: ?>
<form class = "form-signup" action = "<?php echo e(url('/login')); ?>" method = "post">
    <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="text" name = "username" placeholder="Username" class="form" required autofocus>
        </div>
        <div class="form-group">
            <input type="password" name="pass" placeholder="Password" class="form" required autofocus>
        </div>
        <table>
            <tr>
            <td><button type="submit" class="btn btn-warning">Sign in</button></td>
            <td>&nbsp;</td>
            <td><a href="<?php echo e(url('register')); ?>">Sign up</a></td>
            </tr>
       </table>
</form>
<?php endif; ?>